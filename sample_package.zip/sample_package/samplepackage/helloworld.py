class helloworld:
    def hello(self):
      print("Hello World!")